package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "videos")
data class VideoEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val description: String,
    val videoUrl: String,
    val thumbnailUrl: String = "",
    val thumbnailResId: Int = 0,
    val videoType: String = "LONG", // "LONG" or "SHORT"
    val durationText: String = "10:24",
    val viewsCount: String = "14.2K",
    val publishDate: String = "۳ روز پیش",
    val likesCount: Int = 1420,
    val isFeatured: Boolean = false,
    val isTrending: Boolean = false,
    val tags: String = "تولید ویدیو,تجهیزات,آموزش",
    val createdAt: Long = System.currentTimeMillis()
)
