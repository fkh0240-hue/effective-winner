package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(entities = [VideoEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun videoDao(): VideoDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "mohammad_ord_videos.db"
                ).addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        // Seed initial showcase videos
                        CoroutineScope(Dispatchers.IO).launch {
                            getInstance(context).videoDao().insertAll(getInitialSeedVideos())
                        }
                    }
                }).build()
                INSTANCE = instance
                instance
            }
        }

        fun getInitialSeedVideos(): List<VideoEntity> {
            return listOf(
                VideoEntity(
                    id = 1,
                    title = "راهنمای جامع فیلم‌برداری سینمایی با دوربین‌های مدرن | تکنیک‌های محمد ارد",
                    description = "در این قسمت تخصصی، به بررسی عمق میدان، انتخاب لنزهای آنامورفیک و تنظیمات نورپردازی در استودیو می‌پردازیم. تجربیات چندین ساله کار با دوربین‌های سینمایی را با شما به اشتراک گذاشته‌ام.",
                    videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
                    thumbnailResId = R.drawable.thumb_studio_gear_1790242797129,
                    videoType = "LONG",
                    durationText = "۱۸:۴۵",
                    viewsCount = "۴۲.۵ هزار بازدید",
                    publishDate = "۲ روز پیش",
                    likesCount = 3840,
                    isFeatured = true,
                    isTrending = true,
                    tags = "فیلم‌برداری,تجهیزات,نورپردازی,محمد ارد"
                ),
                VideoEntity(
                    id = 2,
                    title = "انقلاب هوش مصنوعی در تدوین و پست پروداکشن | آینده مدیا چگونه تغییر می‌کند؟",
                    description = "نگاهی عمیق به ابزارهای نسل جدید هوش مصنوعی در ویرایش تصویر، کالرگریدینگ اتوماتیک و سرعت بخشیدن به فرآیند تدوین ویدیو.",
                    videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
                    thumbnailResId = R.drawable.thumb_ai_tech_1790242783148,
                    videoType = "LONG",
                    durationText = "۱۴:۲۰",
                    viewsCount = "۲۸.۱ هزار بازدید",
                    publishDate = "۱ هفته پیش",
                    likesCount = 2190,
                    isFeatured = true,
                    isTrending = false,
                    tags = "هوش مصنوعی,تکنولوژی,تدوین,آموزش"
                ),
                VideoEntity(
                    id = 3,
                    title = "یک ترفند طلایی برای نورپردازی چهره در ۵ ثانیه! 🔥",
                    description = "تکنیک سریع استفاده از نور متضاد برای ایجاد کنتراست عمیق در ویدیوهای عمودی و پرتره.",
                    videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
                    thumbnailResId = R.drawable.thumb_short_vertical_1790243111331,
                    videoType = "SHORT",
                    durationText = "۰۰:۵۸",
                    viewsCount = "۹۵.۴ هزار بازدید",
                    publishDate = "دیروز",
                    likesCount = 8900,
                    isFeatured = true,
                    isTrending = true,
                    tags = "شورتز,ترفند,نورپردازی"
                ),
                VideoEntity(
                    id = 4,
                    title = "پشت صحنه ساخت تیزر تبلیغاتی بین‌المللی | مستند یک پروژه واقعی",
                    description = "صفر تا صد فیلم‌برداری میدانی، چالش‌های صدابرداری سر صحنه و نحوه کارگردانی تیم فنی در لوکیشن‌های سخت.",
                    videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
                    thumbnailResId = R.drawable.channel_banner_1790242700055,
                    videoType = "LONG",
                    durationText = "۲۲:۱۰",
                    viewsCount = "۵۱.۰ هزار بازدید",
                    publishDate = "۲ هفته پیش",
                    likesCount = 4720,
                    isFeatured = false,
                    isTrending = true,
                    tags = "پشت صحنه,مستند,کارگردانی"
                ),
                VideoEntity(
                    id = 5,
                    title = "تنظیم صحیح میکروفون بووم در ۳ مرحله ساده 🎙️",
                    description = "چطور صدایی شفاف بدون نویز محیطی ضبط کنیم؟ نکته کلیدی فاصله و زاویه کپسول میکروفون.",
                    videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
                    thumbnailResId = R.drawable.mohammad_ord_logo_1790242686465,
                    videoType = "SHORT",
                    durationText = "۰۰:۴۵",
                    viewsCount = "۶۴.۲ هزار بازدید",
                    publishDate = "۴ روز پیش",
                    likesCount = 5310,
                    isFeatured = false,
                    isTrending = false,
                    tags = "شورتز,صدا,میکروفون"
                )
            )
        }
    }
}
