package com.example.data;

/**
 * Constants for Mohammad Ord brand assets and channel info.
 */
public final class ChannelConstants {
    private ChannelConstants() {}

    public static final String CHANNEL_NAME = "محمد ارد";
    public static final String CHANNEL_TAGLINE = "فیلم‌ساز، کارگردان و تولیدکننده محتوای تخصصی";
    public static final String CHANNEL_BIO = "به کانال رسمی محمد ارد خوش آمدید. در اینجا آخرین ویدیوهای آموزشی، نقد و بررسی تجهیزات سینمایی، مستندات کوتاه و پشت‌صحنه‌های تولید را تماشا کنید.";
    public static final String SUBSCRIBER_COUNT = "۱۲۸ هزار مشترک";
    public static final String VIDEO_COUNT = "۵۴ ویدیو";
    public static final String ADMIN_PIN = "1234";

    public static final int DEFAULT_BANNER_RES = com.example.R.drawable.channel_banner_1790242700055;
    public static final int DEFAULT_AVATAR_RES = com.example.R.drawable.creator_avatar_1790242711897;
    public static final int DEFAULT_LOGO_RES = com.example.R.drawable.mohammad_ord_logo_1790242686465;
}
