package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface VideoDao {
    @Query("SELECT * FROM videos ORDER BY createdAt DESC")
    fun getAllVideos(): Flow<List<VideoEntity>>

    @Query("SELECT * FROM videos WHERE videoType = 'LONG' ORDER BY createdAt DESC")
    fun getLongVideos(): Flow<List<VideoEntity>>

    @Query("SELECT * FROM videos WHERE videoType = 'SHORT' ORDER BY createdAt DESC")
    fun getShortVideos(): Flow<List<VideoEntity>>

    @Query("SELECT * FROM videos WHERE isFeatured = 1 OR isTrending = 1 ORDER BY createdAt DESC")
    fun getFeaturedVideos(): Flow<List<VideoEntity>>

    @Query("SELECT * FROM videos WHERE id = :videoId LIMIT 1")
    suspend fun getVideoById(videoId: Long): VideoEntity?

    @Query("SELECT COUNT(*) FROM videos")
    suspend fun getCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(video: VideoEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(videos: List<VideoEntity>)

    @Update
    suspend fun update(video: VideoEntity)

    @Delete
    suspend fun delete(video: VideoEntity)

    @Query("DELETE FROM videos WHERE id = :videoId")
    suspend fun deleteById(videoId: Long)
}
